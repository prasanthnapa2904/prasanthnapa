$(window).adaptTo("foundation-registry").register("foundation.validation.validator", {

  selector: "[data-foundation-validation^='multifield-min']",
  validate: function(el) {
    var textField = document.querySelector("#eventcheckbox");
	var validationName = el.getAttribute("data-validation")
    var min = validationName.replace("multifield-min-", "");
      min = parseInt(min);
      if (textField.checked && el.items.length < min){
          return "Min allowed items is "+ min
    	}

  	}
});


$(window).adaptTo("foundation-registry").register("foundation.validation.validator", {
  selector: "[data-foundation-validation^='multifield-min']",
  validate: function(el) {
      var field =$(".mylocation");
      var locations = [];
      var flag=true;
	  field.each(function(index){
          if($(this).val()!="Others"){
              if(locations.indexOf($(this).val())==-1){
				locations.push($(this).val());
              }
              else{
				flag=false;
              }
          }
	  });
      if(!flag){
		  return "Duplicate location details exists"
      }
}
});