(function (document, $) {
  "use strict";
  $(document).on("change", ".cq-dialog-dropdown-showhide", function (e) {
    showHide($(this));
  });

  $(document).on("foundation-contentloaded", function (e) {
	$(".cq-dialog-dropdown-showhide").each(function (i, element) {
      showOthers(element);
    });
  });


  $(document).on("click", "._coral-Tabs-item", function (e) {
   validateEventDetails();
  });



  $(document).on("dialog-closed", function() {
	validateEventDetails();
  });



  function showOthers(el) {
    var dd = $(el);

    if (dd.val() == "Others") {
      $(el).parent().next().removeClass("hide");
      $(el)
        .parent()
        .next()
        .find("._coral-Textfield")
        .attr("aria-required", true);
    } else {
      $(el).parent().next().addClass("hide");
      $(el)
        .parent()
        .next()
        .find("._coral-Textfield")
        .attr("aria-required", false);
    }
  }
  function showHide(el) {
    el.each(function (i, element) {
      showOthers(element);
    });
  }

    function validateEventDetails(){
        var ui = $(window).adaptTo("foundation-ui");
		var value = $("[name='./eventDetails']");
        var isEvent = $("[name='./isEvent']");
		//console.log(isEvent);
        if(isEvent=="true" && value.length==0){
			ui.alert("Please add atleast one article details");
        }
		return false;

    }
})(document, Granite.$);