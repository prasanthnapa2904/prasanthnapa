(function (document, $) {
  "use strict";
  $(document).on("change", ".cq-dialog-dropdown-showhide", function (e) {
    var ui = $(window).adaptTo("foundation-ui");
    ui.alert("You have selected a"+ $(this).val() +" image");
  });

})(document, Granite.$);